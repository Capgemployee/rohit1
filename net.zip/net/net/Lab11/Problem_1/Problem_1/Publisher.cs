﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Problem_1;

namespace Problem_1
{
    class Publisher
    {
        public event EVentHandlerDelegate MyClickEvent;
        public void InvokeClickEvent()
        {
            if (MyClickEvent != null)
            {
                CreditCard c2 = new CreditCard();
                c2.MakePayment();
            }
            else
            {
                Console.WriteLine("There is no any event handler available");
            }
        }
    }
}
