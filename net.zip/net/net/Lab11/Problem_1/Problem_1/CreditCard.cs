﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
{
    class CreditCard
    {
        public static double balance=100000, creditLimit=40000; 
        public void GetBalance()
        {
            Console.WriteLine("Your Account balance is :- " +balance);
        }
        public void GetCreditLimit()
        {
            Console.WriteLine("Credit Limit of your account is :- " + creditLimit);
        }

        public void MakePayment()
        {
            Console.WriteLine(" Enter the amount to be pay");
            double pay = Convert.ToDouble(Console.ReadLine());
            balance = balance -pay;
            Console.WriteLine(" Your Payment is Successful");
            GetBalance();
        }

    }
}
