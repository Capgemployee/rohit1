﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem_1
{
    public delegate void EVentHandlerDelegate();
    class Program
    {
        static void Main(string[] args)
        {
            Publisher pub = new Publisher();
            Subscriber sub = new Subscriber();
            CreditCard c = new CreditCard();

            Console.WriteLine("*******************************************************************");
            Console.WriteLine("                           ICICI Bank                              ");
            Console.WriteLine("*******************************************************************");
            Console.WriteLine("Please Select Your Transaction");
            Console.WriteLine("1. Balance Check   2. Credi Limit 3. Make Payment");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    c.GetBalance();
                    break;

                case 2:
                    c.GetCreditLimit();
                    break;

                case 3:
                     pub.MyClickEvent += sub.HandlerMethod;
                     pub.InvokeClickEvent();
                    break;

                default:
                    Console.WriteLine("Please Select Valid Operation");
                    break;
            }

            Console.ReadKey();
        }
    }
}
