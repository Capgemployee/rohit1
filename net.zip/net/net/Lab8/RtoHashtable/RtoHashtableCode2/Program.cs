﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace RtoHashtableCode2
{
    class Program
    {
        static Hashtable GetHashtable()
        {
            // Create and return new Hashtable.
            Hashtable hashtable = new Hashtable();
            hashtable.Add("Area", 1000);
            hashtable.Add("Perimeter", 55);
            hashtable.Add("Mortgage", 540);
            return hashtable;
        }

        static void Main(string[] args)
        {
            Hashtable hs = GetHashtable();
            if (hs.ContainsKey("Perimeter"))
                Console.WriteLine("This Hashtable Contains the key Perimeter");
            else
                Console.WriteLine("This Hashtable does not  Contains the key Perimeter");
            
            Console.Write("\n");

            Console.WriteLine("The value of the key: Area is "+hs["Area"]);

            Console.WriteLine("Before removing the entry for key-Mortgage, the number of records are " + hs.Count);
         hs.Remove("Mortgage");
         Console.WriteLine("After removing the entry for key-Mortgage, the number of records are " + hs.Count);
        }

       
    }
}
