﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace RtoHashtable
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable ht = new Hashtable();
            Console.WriteLine("The no of records before adding any value is "+ht.Count);
            ht.Add("MH01","Mumbai");
            ht.Add("MH50","Mumbai");
            ht.Add("MH12", "Thane");
            ht.Add("GJ10", "Surat");
            ht.Add("MP11", "Delhi");
            Console.WriteLine("The no of records after adding values is "+ ht.Count);
            Console.WriteLine("Enter the Name plate to know the Location ");

            String namePlate = Console.ReadLine();

            Console.WriteLine("The Car is of "+ht[namePlate]+" Loaction");
            
            foreach(String key in ht.Keys)
            {   
                Console.Write("Car" + key + "Location" + ht[key]+"\t");
                Console.Write("\n");
                
            }
            Console.WriteLine("And the no of records  is " + ht.Count);

            Console.WriteLine("Enter the name plate of the car Which you want to remove from RTO Records");
            String nameplate = Console.ReadLine();

            ht.Remove(nameplate);
            Console.WriteLine("Record Removed And the number of records are "+ht.Count);
            

         }
    }
}
