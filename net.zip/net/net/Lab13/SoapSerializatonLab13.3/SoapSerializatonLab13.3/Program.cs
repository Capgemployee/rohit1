﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Soap;
using System.Collections;
namespace SoapSerializatonLab13._3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            char con = 'Y';
            ArrayList ct = new ArrayList();
            Console.WriteLine("Enter the information of the Contacts");
            do
            {
                Console.Write("Enter the Contact No :");
                int contactNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the name Of Contacts");
                String name = Console.ReadLine();
                Console.Write("Enter the cell no of contacts");
                String cellNo = Console.ReadLine();
                ct.Add(new Contacts() { ContactNo = contactNo, ContactName = name, CellNo = cellNo });
                Console.WriteLine("The details are entered,Press 'Y' to continue And any other key to exit");
                con = Convert.ToChar(Console.ReadLine());

            } while (con == 'Y');

            FileStream fs = new FileStream("Soapcontacts.txt", FileMode.Create, FileAccess.Write);

            SoapFormatter bf = new SoapFormatter();
            bf.Serialize(fs,ct);
            Console.WriteLine("Details entered into file : 'contacts.txt' as follows ");
            fs.Close();

            FileStream fs1 = new FileStream("Soapcontacts.txt", FileMode.Open, FileAccess.Read);
            ArrayList l2 = (ArrayList)bf.Deserialize(fs1);
            foreach (Contacts cn in l2)
            {
                Console.WriteLine("Contacts{0} Id : {1}", i, cn.ContactNo);
                Console.Write("Contacts{0} Name: {1}", i, cn.ContactName);
                Console.Write("Contacts{0} CellNo : {1}", i, cn.CellNo);
                i += 1;
                Console.Write("\n");
            }

            Console.ReadKey();
        }
    }
}
