﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace BinarySerialzationLab13._2
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            char con = 'Y';
            List<Contacts> ct = new List<Contacts>();
            Console.WriteLine("Enter the information of the Contacts");
            do
            {
                Console.Write("Enter the Contact No :");
                int contactNo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter the name Of Contacts");
                String name = Console.ReadLine();
                Console.Write("Enter the cell no of contacts");
                String cellNo = Console.ReadLine();
                ct.Add(new Contacts() { ContactNo = contactNo, ContactName = name, CellNo = cellNo });
                Console.WriteLine("The details are entered,Press 'Y' to continue And any other key to exit");
                con = Convert.ToChar(Console.ReadLine());

            } while (con == 'Y');

            FileStream fs = new FileStream("contacts.txt", FileMode.Create, FileAccess.Write);

            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, ct);
            Console.WriteLine("Details entered into file : 'contacts.txt' as follows ");
            fs.Close();

            FileStream fs1 = new FileStream("contacts.txt", FileMode.Open, FileAccess.Read);
            List<Contacts> l2 = (List<Contacts>)bf.Deserialize(fs1);
            foreach (Contacts cn in l2)
            {
                Console.WriteLine("Contacts{0} Id : {1}", i, cn.ContactNo);
                Console.Write("Contacts{0} Name: {1}", i, cn.ContactName);
                Console.Write("Contacts{0} CellNo : {1}", i, cn.CellNo);
                i += 1;
                Console.Write("\n");
            }

            Console.ReadKey();
        }
    }
}
