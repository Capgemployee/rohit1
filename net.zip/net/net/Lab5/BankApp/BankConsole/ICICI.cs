﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankConsole
{
    class ICICI:BankAccount
    {
        public override int Withdraw(int amount)
        {
            if (Balance - amount >= 0)
            {
                Balance -= amount;
                return amount;
            }
            else
            {
                Console.WriteLine("Balance is Low");
                return amount;
            }
            
        }

        public override void Transfer(BankAccount toAccount, int amount)
        {
            if (this.Balance - amount >= 1000)
            {
                Balance = Balance - amount;
                toAccount.Balance = toAccount.Balance + amount;
                
            }
            else
            {
                Console.WriteLine("Balance is low");
            }
        }

        public override double GetBalance()
        {
            return (Balance);
        }
    }
    class HSBC : BankAccount
    {
        public override int Withdraw(int amount)
        {
            if (Balance - amount >= 5000)
            {
                Balance -= amount;
                return amount;
            }
            else
            {
                Console.WriteLine("Balance is Low");
                return amount;
            }

        }

        public override void Transfer(BankAccount toAccount, int amount)
        {
            if (Balance - Withdraw(amount) >= 5000)
            {
                toAccount.Balance = Balance + amount;
            }
            else
            {
                Console.WriteLine("Balance is low");
            }
        }

        public override double GetBalance()
        {
            return (Balance);
        }
    }
}
