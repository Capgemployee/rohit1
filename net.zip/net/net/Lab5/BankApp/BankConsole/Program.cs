﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            ICICI icici = new ICICI();
            //BankAccount b = new BankAccount();
            BankAccount.BankAccountTypeEnum enum1=BankAccount.BankAccountTypeEnum.Current;
            //icici.AccountType = enum1;
            icici.AccountType =icici.getType(BankAccount.BankAccountTypeEnum.Saving);
            icici.Deposit(50000);
            int a = icici.Balance;

            ICICI icici1 = new ICICI();
            icici1.AccountType = icici1.getType(BankAccount.BankAccountTypeEnum.Current);
            icici1.Deposit(20000);
            int b = icici1.Balance;
            Console.WriteLine("Account balance of {0} account  is      :{1}",icici.AccountType,a);
            Console.WriteLine("Account balance of {0} account  is      :{1}",icici1.AccountType,b);
            icici.Withdraw(5000);
            icici.Transfer(icici1, 5000);
            Console.WriteLine("Account balance of {0} account  is      :{1}", icici.AccountType, icici.Balance);
            Console.WriteLine("Account balance of {0} account  is      :{1}", icici1.AccountType, icici1.Balance);



        }
    }
}
