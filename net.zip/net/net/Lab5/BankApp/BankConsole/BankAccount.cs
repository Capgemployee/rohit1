﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankConsole
{
    public abstract class BankAccount:IBankAccount
    {
        public enum BankAccountTypeEnum
        {
            Current = 1,
            Saving = 2
        }
        public int Balance { get; set; }
        public abstract double GetBalance();

        public void Deposit(int amount)
        {
            this.Balance += amount;
        }

        public abstract int Withdraw(int amount);
        public abstract void Transfer(BankAccount toAccount, int amount);

        public string AccountType { get; set; }
        public string getType(BankAccountTypeEnum acc)
        {
            switch (acc)
            {
                case BankAccountTypeEnum.Current:
                    return "Current";
                    break;
                case BankAccountTypeEnum.Saving:
                    return "Saving";
                    break;
                default:
                    return null;
                    break;
            }
        }
    }
}
