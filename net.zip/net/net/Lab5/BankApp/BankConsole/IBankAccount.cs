﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankConsole
{
    interface IBankAccount
    {
        
        double GetBalance();
        void Deposit(int amount);
        int Withdraw(int amount);
        void Transfer(BankAccount toAccount, int amount);
        string AccountType { get; set; }
    }
}
