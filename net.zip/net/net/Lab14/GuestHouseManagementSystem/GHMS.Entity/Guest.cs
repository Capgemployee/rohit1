﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.Entity
{
    public enum Relation
    {
        FATHER,
        MOTHER,
        BROTHER,
        SISTER,
        COUSIN,
        UNCLE,
        AUNT,
        SON,
        DAUGHTER,
        FRIEND
    }
    
    public class Guest
    {
        
        public int GuestID { get; set; }
        public string GuestName { get; set; }
        public Relation RelationShip { get; set; }
        public string GuestContactNumber { get; set; }

        public Guest()
        {
        }

    }
}
