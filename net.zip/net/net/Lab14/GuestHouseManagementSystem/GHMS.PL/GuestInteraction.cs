﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GHMS.Entity;
using GHMS.Exception;
using GHMS.BAL;

namespace GHMS.PL
{
    class GuestInteraction
    {
        public static void AddGuest()
        {
            Guest gst = new Guest();
            try 
            {
                Console.Write("Enter Guest ID : ");
                gst.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Guest Name : ");
                gst.GuestName = Console.ReadLine();
                Console.Write("Enter Phone Number : ");
                gst.GuestContactNumber = Console.ReadLine();
                
                Console.Write("Enter Relation : ");
                Console.WriteLine("Choose one relation\n1)FATHER\n2)MOTHER\n3)BROTHER\n4)SISTER\n5)COUSIN\n6)UNCLE\n7)AUNT\n8)SON\n9)DAUGHTER\n10)FRIEND");
                Console.Write("Enter Choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1: gst.RelationShip = Relation.FATHER;
                        break;
                    case 2: gst.RelationShip = Relation.MOTHER;
                        break;
                    case 3: gst.RelationShip = Relation.BROTHER;
                        break;
                    case 4: gst.RelationShip = Relation.SISTER;
                        break;
                    case 5: gst.RelationShip = Relation.COUSIN;
                        break;
                    case 6: gst.RelationShip = Relation.UNCLE;
                        break;
                    case 7: gst.RelationShip = Relation.AUNT;
                        break;
                    case 8: gst.RelationShip = Relation.SON;
                        break;
                    case 9: gst.RelationShip = Relation.DAUGHTER;
                        break;
                    case 10: gst.RelationShip = Relation.FRIEND;
                        break;
                    default: throw new GuestException("Relation does not exist");
                        break;
                }
                bool empAdded = GuestValidate.AddGuest(gst);

                if (empAdded)
                {
                    Console.WriteLine("Guest Added Successfully");
                }
                else
                {
                    throw new GuestException("Employee not Added");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void UpdateGuest()
        {
            Guest gst = new Guest();

            try
            {
                Console.Write("Enter Guest ID to be updated : ");
                gst.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Modified Guest Name : ");
                gst.GuestName = Console.ReadLine();
                Console.Write("Enter Modified Phone Number : ");
                gst.GuestContactNumber = Console.ReadLine();
                Console.Write("Enter Modified Relation ship");
                Console.WriteLine("Choose one relation\n1)FATHER\n2)MOTHER\n3)BROTHER\n4)SISTER\n5)COUSIN\n6)UNCLE\n7)AUNT\n8)SON\n9)DAUGHTER\n10)FRIEND");
                Console.Write("Enter Choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1: gst.RelationShip = Relation.FATHER;
                        break;
                    case 2: gst.RelationShip = Relation.MOTHER;
                        break;
                    case 3: gst.RelationShip = Relation.BROTHER;
                        break;
                    case 4: gst.RelationShip = Relation.SISTER;
                        break;
                    case 5: gst.RelationShip = Relation.COUSIN;
                        break;
                    case 6: gst.RelationShip = Relation.UNCLE;
                        break;
                    case 7: gst.RelationShip = Relation.AUNT;
                        break;
                    case 8: gst.RelationShip = Relation.SON;
                        break;
                    case 9: gst.RelationShip = Relation.DAUGHTER;
                        break;
                    case 10: gst.RelationShip = Relation.FRIEND;
                        break;
                }

                bool guestUpdated = GuestValidate.UpdateGuest(gst);

                if (guestUpdated)
                {
                    Console.WriteLine("Employee Details Updated Successfully");
                }
                else
                {
                    throw new GuestException("Employee Details not Updated");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DeleteGuest()
        {
            int guestId;

            try 
            {
                Console.Write("Enter Guest Id  of the guest who has to be Deleted : ");
                guestId = Convert.ToInt32(Console.ReadLine());

                bool guestDeleted = GuestValidate.DeleteGuest(guestId);

                if (guestDeleted)
                {
                    Console.WriteLine("Employee Details deleted Successfully");
                }
                else
                {
                    throw new GuestException("Employee details cannot be deleted");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void DisplayAllGuest()
        {
            try 
            {
                List<Guest> guestList = GuestValidate.DisplayAllGuest();

                if (guestList.Count>0)
                {
                    Console.WriteLine("********************************************************************************************");
                    Console.WriteLine("********************************************************************************************");
                    foreach (Guest g in guestList)
                    {
                        Console.WriteLine(g.GuestID + "\t" + g.GuestName  + "\t" + g.GuestContactNumber + "\t" + g.RelationShip);
                    }
                    Console.WriteLine("********************************************************************************************");
                }
                else
                {
                    throw new GuestException("Employee List is Empty");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void SearchGuestRelation()
        {
            try
            {
                List<Guest> guestList = GuestValidate.DisplayAllGuest();
                Console.WriteLine("Choose one relation\n1)FATHER\n2)MOTHER\n3)BROTHER\n4)SISTER\n5)COUSIN\n6)UNCLE\n7)AUNT\n8)SON\n9)DAUGHTER\n10)FRIEND");
                Console.Write("Enter Choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                Relation r=new Relation();
                switch (ch)
                {
                    case 1: r = Relation.FATHER;
                        break;
                    case 2: r = Relation.MOTHER;
                        break;
                    case 3: r = Relation.BROTHER;
                        break;
                    case 4: r = Relation.SISTER;
                        break;
                    case 5: r = Relation.COUSIN;
                        break;
                    case 6: r = Relation.UNCLE;
                        break;
                    case 7: r = Relation.AUNT;
                        break;
                    case 8: r = Relation.SON;
                        break;
                    case 9: r = Relation.DAUGHTER;
                        break;
                    case 10: r = Relation.FRIEND;
                        break;
                }
                List<Guest> gst = new List<Guest>();
                gst = GuestValidate.SearchGuestRelation(r);
                if (gst.Count > 0)
                {
                    Console.WriteLine("********************************************************************************************");
                    Console.WriteLine("********************************************************************************************");
                    foreach (Guest g in gst)
                    {
                        Console.WriteLine(g.GuestID + "\t" + g.GuestName + "\t" + g.GuestContactNumber + "\t" + g.RelationShip);
                    }
                    Console.WriteLine("********************************************************************************************");
                }
                else
                {
                    throw new GuestException("Employee List is Empty");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        static void Main(string[] args)
        {
            int choice = 0;

            try
            {
                do
                {

                    Console.WriteLine("*************Employee Management System************");
                    Console.WriteLine("1. Add Guest");
                    Console.WriteLine("2. Update Guest");
                    Console.WriteLine("3. Delete Guest");
                    Console.WriteLine("4. Display All Guests");
                    Console.WriteLine("5. Search Guest by Relation");
                    Console.WriteLine("****************************************************");
                    Console.Write("Enter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddGuest();
                            break;
                        case 2: UpdateGuest();
                            break;
                        case 3: DeleteGuest();
                            break;
                        case 4: DisplayAllGuest();
                            break;
                        case 5: SearchGuestRelation();
                            break;
                        default: Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (choice != 8);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }         
        }
    }
}
