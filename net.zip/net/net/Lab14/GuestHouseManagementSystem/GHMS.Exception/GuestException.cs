﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GHMS.Exception
{
    public class GuestException:ApplicationException
    {
        /// <summary>
        /// Guest ID :
        /// Guest Name :
        /// Description : User defined Exception class for Guest
        /// Date of Creation :
        /// </summary>
       
            //Default Constructor
            public GuestException()
                : base()
            { }

            //Parameterized Constructor
            public GuestException(string message)
                : base(message)
            { }
        
    }
}
