﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GHMS.Entity;
using GHMS.DAL;
using System.Text.RegularExpressions;
using GHMS.Exception;
namespace GHMS.BAL
{
    public class GuestValidate
    {
        public static bool ValidateGuest(Guest gst)
        {
            bool guestValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                if (gst.GuestID <10000 || gst.GuestID>99999)
                {
                    message.Append("Guest id should be of 5 digits only");
                    guestValidated = false;
                }
                if(gst.GuestContactNumber == String.Empty)
                {
                    message.Append("Phone number cannot be empty");
                    guestValidated=false;
                }
                else if(!Regex.IsMatch(gst.GuestContactNumber,"[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should be 10 digits");
                    guestValidated=false;
                }
                if (guestValidated == false)
                {
                    throw new GuestException ( message.ToString());
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestValidated;

        }

        public static bool AddGuest(Guest gst)
        {
            bool guestAdded = false;
            try
            {
                if (ValidateGuest(gst))
                {
                    guestAdded = GuestHouseOperation.AddGuest(gst);
                }
                else
                {
                    throw new GuestException("Guest Details are invalid");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestAdded;
        }

        public static bool UpdateGuest(Guest gst)
        {
            bool guestUpdated = false;
            try
            {
                if (ValidateGuest(gst))
                {
                    guestUpdated = GuestHouseOperation.UpdateGuest(gst);
                }
                else
                {
                    throw new GuestException("Guest Details are invalid");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestUpdated;
        }

        public static bool DeleteGuest(int guestId)
        {
            bool guestDeleted = false;
            try
            {
            guestDeleted = GuestHouseOperation.DeleteGuest(guestId);
            guestDeleted = true;
            }
            catch(GuestException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return guestDeleted;
        }
        
        public static Guest SearchGuestID(int guestID)
        {
             Guest gst = null;
             try
             {
                 gst = GuestHouseOperation.SearchGuestID(guestID);
             }
             catch (GuestException ex)
             {
                 throw ex;
             }
             catch (SystemException ex)
             {
                 throw ex;
             }
             return gst;
         }

         public static List<Guest> SearchGuestRelation(Relation relation)
         {
             List<Guest> gst = new List<Guest>();
             try
             {  
                gst = GuestHouseOperation.SearchGuestRelation(relation);
             }
             catch(GuestException ex)
             {
                 throw ex;
             }
             catch(SystemException ex)
             {
                 throw ex;
             }
             return gst;
         }

         public static List<Guest> DisplayAllGuest()
        {
            List<Guest> guestList = null;
            try
            {
                guestList = GuestHouseOperation.DisplayAllGuest();
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestList;
        }

     }
 }
