﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GHMS.Entity;
using GHMS.Exception;
namespace GHMS.DAL
{
    public class GuestHouseOperation
    {
        public static List<Guest> guestList = new List<Guest>();
        public static bool AddGuest(Guest gst)
        {
            bool gstAdded = false;
            try
            {
                guestList.Add(gst);
                gstAdded = true;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gstAdded;
        }
        public static List<Guest> DisplayAllGuest()
        {
            return guestList;
        }
        public static Guest SearchGuestID(int guestID)
        {
            Guest gst = null;
            try
            {
                gst = guestList.Find(g => g.GuestID == guestID);

            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gst;
        }
        public static List<Guest> SearchGuestRelation(Relation rel)
        {
            List<Guest> gstList = new List<Guest>();
            try
            {
                for (int i = 0; i < guestList.Count; i++)
                {
                    if (guestList[i].RelationShip == rel)
                    {
                        gstList.Add(guestList[i]);
                    }  
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return gstList;
        }
        public static bool UpdateGuest(Guest guest)
        {
            bool guestUpdated = false;
            try
            {
                for (int i = 0; i < guestList.Count; i++)
                {
                    if (guestList[i].GuestID == guest.GuestID)
                    {
                        guestList[i].GuestName = guest.GuestName;
                        guestList[i].RelationShip = guest.RelationShip;
                        guestList[i].GuestContactNumber = guest.GuestContactNumber;
                        guestUpdated = true;
                    }
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestUpdated;
        }
        public static bool DeleteGuest(int guestID)
        {
            bool guestDeleted = false;
            try
            {
                Guest gst = guestList.Find(g => g.GuestID == guestID);
                guestList.Remove(gst);
                guestDeleted = true;

            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return guestDeleted;
        }
    }
}
