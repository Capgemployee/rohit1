﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails;

namespace EmployeeRecord
{
    class EmployeeRecord
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[2];

            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter Employee ID: ");
                emp[i].setEmployeeId(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Enter Employee Name: ");
                emp[i].setEmployee_Name(Console.ReadLine());
                Console.WriteLine("Enter Employee Address: ");
                emp[i].setAddress(Console.ReadLine());
                Console.WriteLine("Enter Employee City: ");
                emp[i].setCity(Console.ReadLine());
                Console.WriteLine("Enter Employee Department: ");
                emp[i].setEmployee_Name(Console.ReadLine());
                Console.WriteLine("Enter Employee Salary: ");
                emp[i].setSalary(Convert.ToDouble(Console.ReadLine()));
            }
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine(emp[i].getSalary());
                Console.WriteLine(emp[i].getEmployeeName());
            }

        }
    }
}
