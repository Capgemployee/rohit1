﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeProperty
{
    public class Property
    {
        int Empid;
        string Name, Address, City, Department;
        double Salary;
        public int EmployeeId
        {
            get { return Empid; }
            set { Empid = value; }
        }
        public string EmployeeName
        {
            get { return Name; }
            set { Name = value; }
        }
        public string EmployeeAddress
        {
            get { return Address; }
            set { Address = value; }
        }
        public string EmployeeCity
        {
            get { return City; }
            set { City = value; }
        }
        public string EmploeeDepartment
        {
            get { return Department; }
            set { Department = value; }
        }
        public double EmployeeSalary
        {
            get { return Salary; }
            set { Salary = value; }
        }
    }
}
