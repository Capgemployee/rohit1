﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails;
namespace EmployeeApp
{
    class EmployeeApp
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Console.WriteLine("Enter Employee ID: ");
            emp.setEmployeeId(Convert.ToInt32(Console.ReadLine()));
            Console.WriteLine("Enter Employee Name: ");
            emp.setEmployee_Name(Console.ReadLine());
            Console.WriteLine("Enter Employee Address: ");
            emp.setAddress(Console.ReadLine());
            Console.WriteLine("Enter Employee City: ");
            emp.setCity(Console.ReadLine());
            Console.WriteLine("Enter Employee Department: ");
            emp.setEmployee_Name(Console.ReadLine());
            Console.WriteLine("Enter Employee Salary: ");
            emp.setSalary(Convert.ToDouble(Console.ReadLine()));
            Console.WriteLine(emp.getSalary());
        }
    }
}
