﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeProperty;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Property emp = new Property();
            Console.WriteLine("Enter Employee ID: ");
            emp.EmployeeId=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name: ");
            emp.EmployeeName=Console.ReadLine();
            Console.WriteLine("Enter Employee Address: ");
            emp.EmployeeAddress=Console.ReadLine();
            Console.WriteLine("Enter Employee City: ");
            emp.EmployeeCity=Console.ReadLine();
            Console.WriteLine("Enter Employee Department: ");
            emp.EmploeeDepartment=Console.ReadLine();
            Console.WriteLine("Enter Employee Salary: ");
            emp.EmployeeSalary=Convert.ToDouble(Console.ReadLine());

            Console.WriteLine(emp.EmployeeId);
            Console.WriteLine(emp.EmployeeName);
            Console.WriteLine(emp.EmployeeAddress);
            Console.WriteLine(emp.EmployeeCity);
            Console.WriteLine(emp.EmploeeDepartment);
            Console.WriteLine(emp.EmployeeSalary);

            Console.ReadKey();

        }
    }
}
