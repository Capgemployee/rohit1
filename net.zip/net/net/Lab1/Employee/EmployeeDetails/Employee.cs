﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    public class Employee
    {
        int EmployeeId;
        string Employee_Name , Address, City, Department;
        double Salary;
        public void setEmployeeId(int Id)
        {
            EmployeeId = Id;
        }
        public void setEmployee_Name(string name)
        {
            Employee_Name = name;
        }
        public void setAddress(string address)
        {
            Address = address;
        }
        public void setCity(string city)
        {
            City = city;
        }
        public void setDepartment(string department)
        {
            Department = department;
        }
        public void setSalary(double salary)
        {
            Salary = salary;
        }

        public double getSalary()
        {
            return Salary;
        }
        public string getEmployeeName()
        {
            return Employee_Name;
        }
        
    }
}
