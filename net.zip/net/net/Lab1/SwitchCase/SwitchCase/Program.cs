﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCase
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            Console.WriteLine("Enter Number between 1-5");
            choice=Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1: Console.WriteLine("Your Option is one");
                    break;
                case 2: Console.WriteLine("Your Option Is Two");
                    break;
                case 3: Console.WriteLine("Your Option Is Three");
                    break;
                case 4: Console.WriteLine("Your Option Is Four");
                    break;
                case 5: Console.WriteLine("Your Option Is Five");
                    break;
                default:
                Console.WriteLine("Your Option Is wrong");
                break;
            }
        }
    }
}
