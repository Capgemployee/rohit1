﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApp
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassDetails cls = new ClassDetails();
            Console.WriteLine("Enter Student roll number:  ");
            cls.rollNumber=(Convert.ToInt32(Console.ReadLine()));
            Console.WriteLine("Enter Student Name:  ");
            cls.studentName = (Console.ReadLine());
            Console.WriteLine("Enter Student Age:  ");
            cls.age = (Convert.ToByte(Console.ReadLine()));
            Console.WriteLine("Enter Student Gender:  ");
            cls.gender=(Convert.ToChar(Console.ReadLine()));
            Console.WriteLine("Enter Student Date of Birth:  ");
            cls.dateOfBirth = (Convert.ToDateTime(Console.ReadLine()));
            Console.WriteLine("Enter Student Address:  ");
            cls.address=(Console.ReadLine());
            Console.WriteLine("Enter Student Percentage:  ");
            cls.percentage=(Convert.ToDouble(Console.ReadLine()));


            Console.WriteLine(cls.rollNumber);
            Console.WriteLine(cls.studentName);
            Console.WriteLine(cls.age);
            Console.WriteLine(cls.gender);
            Console.WriteLine(cls.dateOfBirth);
            Console.WriteLine(cls.address);
            Console.WriteLine(cls.percentage);

        }
    }
}
