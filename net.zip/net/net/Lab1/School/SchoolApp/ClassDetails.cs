﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolApp
{
    class ClassDetails
    {
        public int rollNumber;
        public string studentName;
        public byte age;
        public char gender;
        public DateTime dateOfBirth;
        public string address;
        public double percentage;
    }
}
