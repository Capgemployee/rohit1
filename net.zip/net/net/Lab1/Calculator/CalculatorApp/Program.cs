﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArithmeticOperations;
namespace CalculatorApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1, num2;
            Char Choice;
            Console.WriteLine("Enter Number1");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Number2");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Choice");
            Console.WriteLine("1)Addition");
            Console.WriteLine("2)Subtraction");
            Console.WriteLine("3)Multiplication");
            Console.WriteLine("4)Division");
            Console.WriteLine("5)Remainder");
            Choice = Convert.ToChar(Console.Read());
            Console.WriteLine("Answer");
            switch (Choice)
            {
                case '1': Console.WriteLine(Operations.Add(num1, num2));
                    break;
                case '2': Console.WriteLine(Operations.Sub(num1, num2));
                    break;
                case '3': Console.WriteLine(Operations.Mul(num1, num2));
                    break;
                case '4': Console.WriteLine(Operations.Div(num1, num2));
                    break;
                case '5': Console.WriteLine(Operations.Mod(num1, num2));
                    break;
            }
        }
    }
}
