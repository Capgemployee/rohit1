﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArithmeticOperations
{
    public class Operations
    {
        public static int Add(int num1, int num2)
        {
            return (num1 + num2);
        }
        public static int Sub(int num1, int num2)
        {
            return (num1 - num2);
        }
        public static int Mul(int num1, int num2)
        {
            return (num1 * num2);
        }
        public static double Div(int num1, int num2)
        {
            return (num1 / num2);
        }
        public static int Mod(int num1, int num2)
        {
            return (num1 % num2);
        }
    }
}
