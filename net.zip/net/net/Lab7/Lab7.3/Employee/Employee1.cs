﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public class Employee1
    {
        int employeeNumber;
        string name;
        int basicSalary;
        int PF;
        public int Enumber 
        {
            get { return employeeNumber;}
            set { employeeNumber=value;} 
        }
        public string Ename 
        {
            get {return name ;}
            set {name=value ;}
        }
        public int Epf 
        {
            get {return PF ;}
            set { PF=value;} 
        }
        public int Ebasicsalary 
        {
            get {return basicSalary ;}
            set {basicSalary=value ;}
        }
        public Employee1()
        {
        }
        public Employee1(int num,string nam,int bsalary,int pf)
        {
            Enumber = num;
            Ename = nam;
            Ebasicsalary = bsalary;
            Epf = pf;
        }
    }
}
