﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;
namespace Lab7._3
{
    class Program
    {
        List<Employee1> emp=new List<Employee1>();
        public void AddEmployee()
        {
            int no;
            string name;
            int salary;
            int pf;
            Console.WriteLine("Enter Employee Number");
            no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Employee Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Basic Salary");
            salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Provident fund");
            pf = Convert.ToInt32(Console.ReadLine());
            emp.Add(new Employee1 { Enumber = no, Ename = name, Ebasicsalary=salary, Epf = pf });
        }
        public void ShowAllEmployee()
        {
            foreach (var item in emp)
            {
                Console.WriteLine("Employee No:{0}   Employee Name:{1}    BAsic Salary:{2}  Provident Fund:{3}", item.Enumber, item.Ename,item.Ebasicsalary, item.Epf);
            }
        }

        public void SearchEmployee()
        {
            Console.WriteLine("Enter Product Number you want to search");
            int no = Convert.ToInt32(Console.ReadLine());
            bool flag = false;
            foreach (var item in emp)
            {
                if (item.Enumber.Equals(no))
                {
                    flag = true;
                    Console.WriteLine("Employee found");
                    Console.WriteLine("Employee No:{0}   Employee Name:{1}    Basic Salary:{2}    PF:{3}   ", item.Enumber, item.Ename, item.Ebasicsalary, item.Epf);

                }
            }
            if (flag == false)
            {
                Console.WriteLine("Product not found");
            }
        }
        public Employee1 Search()
        {
            Console.WriteLine("Enter Employee Number you want to Delete");
            int no = Convert.ToInt32(Console.ReadLine());
            bool flag = false;
            foreach (var item in emp)
            {
                if (item.Enumber.Equals(no))
                {
                    flag = true;
                    Console.WriteLine("Employee found");
                    return item;
                }
            }
            if (flag == false)
            {
                Console.WriteLine("Employee not found");
            }
            return null;
        }
        public void DeleteEmployee()
        {
            emp.Remove(Search());
            Console.WriteLine("Product Deleted");
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            Console.WriteLine("++++++++++++++++++++++++++++++++++");
            Console.WriteLine("         Employee Catalog");
            Console.WriteLine("++++++++++++++++++++++++++++++++++");
            while (true)
            {

                Console.WriteLine("Choices");
                Console.WriteLine("------------------------------");
                Console.WriteLine("1)Add Employee");
                Console.WriteLine("2)Search Employee");
                Console.WriteLine("3)Delete Employee");
                Console.WriteLine("4)Show all Employee");
                Console.WriteLine("5)Quit");
                Console.WriteLine("Enter a choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    p.AddEmployee();
                }
                else if (choice == 2)
                {
                    p.SearchEmployee();
                }
                else if (choice == 3)
                {
                    p.DeleteEmployee();
                }
                else if (choice == 4)
                {
                    p.ShowAllEmployee();
                }
                else if (choice == 5)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Enter Correct Choice");
                }
            }
                      
        }
    }
}
