﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob_7._1
{
    public class Program
    {
        List<Contact> contact = new List<Contact>();
        public void AddContact()
        {
            int no;
            string name;
            string cell;
            Console.WriteLine("Enter Contact Number");
            no = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Contact Name");
            name = Console.ReadLine();
            Console.WriteLine("Enter Cell Number");
            cell = Console.ReadLine();
            contact.Add(new Contact { ContactNo = no, ContactName = name, CellNo = cell });
        }
        public void ShowAllContacts()
        {
            foreach (var item in contact)
            {
                Console.WriteLine("Contact No:{0}   Contact Name:{1}    Cell no:{2}", item.ContactNo, item.ContactName, item.CellNo);
            }
        }
        public void DisplayContact(int no)
        {
            //bool flag = false;
            foreach (var item in contact)
            {
                if (item.ContactNo.Equals(no))
                {
                    Console.WriteLine("Contact found");
                    Console.WriteLine("Contact No:{0}   Contact Name:{1}    Cell no:{2}", item.ContactNo, item.ContactName, item.CellNo);
                }
            }
        }
        public void EditContact()
        {
            int no;
            Console.WriteLine("Enter Contact number u want to change");
            no = Convert.ToInt32(Console.ReadLine());
            foreach (var item in contact)
            {
                if (item.ContactNo.Equals(no))
                {
                    Console.WriteLine("Enter new name");
                    item.ContactName = Console.ReadLine();
                    Console.WriteLine("Enter New Cell No.");
                    item.CellNo = Console.ReadLine();
                }
            }

        }
        static int x;
        static void Main(string[] args)
        {
            Program p = new Program();
            Console.WriteLine("++++++++++++++++++++++++++++++++++");
            Console.WriteLine("         Contact Catalog");
            Console.WriteLine("++++++++++++++++++++++++++++++++++");
            while (true)
            {

                Console.WriteLine("Choices");
                Console.WriteLine("------------------------------");
                Console.WriteLine("1)Add Contact");
                Console.WriteLine("2)Display Contact");
                Console.WriteLine("3)Edit Contact");
                Console.WriteLine("4)Display All Contact");
                Console.WriteLine("5)Quit");
                Console.WriteLine("Enter a choice");
                int choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    p.AddContact();
                }
                else if (choice == 2)
                {
                    Console.WriteLine("Enter Contact no u want to search");
                    p.DisplayContact(Convert.ToInt32( Console.ReadLine()));
                }
                else if (choice == 3)
                {
                    p.EditContact();
                }
                else if (choice == 4)
                {
                    p.ShowAllContacts();
                }
                else if (choice == 5)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Enter Correct Choice");
                }
            }

        }
    }
}
