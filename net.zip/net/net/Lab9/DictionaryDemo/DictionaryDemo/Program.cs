﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{

    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dictonary = new Dictionary<string, string>();
            dictonary.Add("1","Dheeraj");
            dictonary.Add("2", "Deepak");
            dictonary.Add("3", "Dheeraj");
            //dictonary.Add("1", "Pratik");
            
            dictonary["1"] = "Dipika";
            dictonary["3"]="Shweta";
            dictonary.Remove("3");
            dictonary.Remove("5");
            foreach (var item in dictonary)
            {
                Console.WriteLine("key: {0}     value:  {1}", item.Key, item.Value);
            }
        }
    }
}
