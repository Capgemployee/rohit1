﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Exp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the file you want to read");
                string path = Console.ReadLine();
                FileStream fs = new FileStream(path, FileMode.Open,FileAccess.Read);
                string text;
                using (var streamReader = new StreamReader(path, Encoding.UTF8))
                {
                    text = streamReader.ReadToEnd();
                }
                Console.WriteLine(text);

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
