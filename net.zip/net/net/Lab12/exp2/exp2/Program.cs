﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace exp2
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the source of file you want to read");
                string path = Console.ReadLine();
                Console.WriteLine("Enter the destination of file you want to read");
                string path1 = Console.ReadLine();
                FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                FileStream fs1 = new FileStream(path1, FileMode.Create, FileAccess.Write);
                string text;
                StreamWriter str = new StreamWriter(fs1);
                using (var streamReader = new StreamReader(fs, Encoding.UTF8))
                {
                    text = streamReader.ReadToEnd();
                    
                }
                str.WriteLine(text);
                str.Flush();
                fs.Close();
                fs1.Close();
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
