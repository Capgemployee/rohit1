﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Problem3
{
    class Program
    {
        static void Main(string[] args)
        {    string[] subdirectoryname = new string[4];
        Console.WriteLine("Enter the name for a Parent Directory");
        string dirpath = Console.ReadLine();
        DirectoryInfo directoryfile = new DirectoryInfo(@dirpath);
            Console.WriteLine("Enter your choice");
            Console.WriteLine("1)Make Directory and sub files");
            Console.WriteLine("2)Edit in file");
            Console.WriteLine("3) read the file");
           int choices = Convert.ToInt32(Console.ReadLine());

           switch (choices)
           { 
               case 1: 
                  

                   if (directoryfile.Exists)
                   {
                       Console.WriteLine("file found");


                   }
                   else
                   {
                       Directory.CreateDirectory(@dirpath);
                       for (int i = 0; i < 4; i++)
                       {
                           Console.WriteLine("Enter the sub directory Name");
                           subdirectoryname[i] = Console.ReadLine();
                           directoryfile.CreateSubdirectory(@subdirectoryname[i]);
                       }
                   }
                   Console.WriteLine("enter the name of folder you want to create a file");
                   string filepath = Console.ReadLine();
                   string folderpath = Path.Combine(@dirpath, @filepath);
                   DirectoryInfo foldername = new DirectoryInfo(@filepath);
                   for (int i = 0; i < 4; i++)
                   {
                       if (filepath == subdirectoryname[i])
                       {
                           Console.WriteLine("Enter the file name");
                           string filename = Console.ReadLine();
                           string newpath = Path.Combine(@folderpath, @filename);
                           FileInfo file = new FileInfo(newpath);
                           file.Create();

                       }
                   }

                   break;
               case 2:
                        Console.WriteLine("File editing ");
            Console.WriteLine("Enter the path name of the file  you want to write");
        string filePath= Console.ReadLine();

            FileStream fs1 = new FileStream(filePath, FileMode.Open, FileAccess.Write);
            
            StreamWriter str = new StreamWriter(fs1);

            str.WriteLine("asdfasdf");
            str.Flush();
            fs1.Close();
            Console.ReadKey();

                   break;
               case 3:
                        Console.WriteLine("read the files created ");
            Console.WriteLine("Enter the folder name of the file  you want to read");
            String Foldername = Console.ReadLine();
            String foldpath = Path.Combine(@dirpath, @Foldername);
            Console.WriteLine("enter the file name you want to acess");
            String filenames = Console.ReadLine();
            String fileaccess = Path.Combine(@foldpath, @filenames);
            FileInfo foldname = new FileInfo(fileaccess);
            FileStream fileData = new FileStream(fileaccess, FileMode.Open, FileAccess.Read);
            StreamReader br = new StreamReader(fileData);
            Console.WriteLine(br.ReadToEnd());
            Console.ReadKey();
         

                   break;

           }

         
       
       
            }
        }



    }