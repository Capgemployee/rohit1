﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class SupplierTest: Supplier
    {
        static void Main(string[] args)
        {
            SupplierTest sp = new SupplierTest();
            int id;
            String name, scity, sphone, semail;
            Console.WriteLine("Enter Supplier Id");
            id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Supplier name");
            name = Console.ReadLine();
            Console.WriteLine("Enter city name");
            scity = Console.ReadLine();
            Console.WriteLine("Enter Phone Number");
            sphone = Console.ReadLine();
            Console.WriteLine("Enter supplier email id");
            semail = Console.ReadLine();
            sp.AcceptDetails(id, name, scity, sphone, semail);
            sp.DisplayDetails();

        }
    }
}
