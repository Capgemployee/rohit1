﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication4
{
    class Supplier
    {
        private int supplierId;
        private string supplierName;
        private string city;
        private string phoneNo;
        private string email;
        public void AcceptDetails(int a,string b,string c,string d,string e)   
        {
            supplierId = a;
            supplierName = b;
            city = c;
            phoneNo = d;
            email = e;
        }
        public void  DisplayDetails()
        {
            Console.WriteLine("Supplier Id          :"+supplierId);
            Console.WriteLine("Supplier Name        :"+supplierName);
            Console.WriteLine("City                 :"+city);
            Console.WriteLine("Phone Number         :"+phoneNo);
            Console.WriteLine("Email Id             :"+email);
        }
    }
}
