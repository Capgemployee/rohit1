﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] array = new string[5];
            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine("Enter data for array {0}",i);
                array[i] = Console.ReadLine();
            }
            foreach (var item in array)
            {
                Console.Write("Value of array {0}:");
                Console.WriteLine(item);
            }
        }
    }
}
