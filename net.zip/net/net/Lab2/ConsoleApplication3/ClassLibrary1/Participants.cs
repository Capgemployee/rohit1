﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Participants
    {
        private int EmpId;
        private string Name, CompanyName;
        private int FoundationMarks,WebBasicMarks,DotNetMarks,TotalMarks,ObtainedMarks, Percentage;
        public int EmpId { get; set; }
    }
}
