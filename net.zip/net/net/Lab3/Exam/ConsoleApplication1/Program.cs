﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Speech.Synthesis;
using ClassLibrary1;
namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            Class1 cls = new Class1();
            Console.WriteLine("Enter Employee Id");
            cls.empId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            cls.name = Console.ReadLine();
            Console.WriteLine("Enter Company Name");
            cls.companyName = Console.ReadLine();
            Console.WriteLine("Enter FoundationMarks");
            cls.foundationMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter WebBasicMarks");
            cls.webBasicMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter DotNetMarks");
            cls.dotNetMarks = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("--------------------------------------------------");
            Console.WriteLine("EmpID            :" + cls.empId);
            Console.WriteLine("Employee Name    :" + cls.name);
            Console.WriteLine("Company name     :" + cls.companyName);
            Console.WriteLine("Marks Obtained   :" + cls.getTotalMarks());
            Console.WriteLine("Percentage       :" + cls.getPercentage());

        }
    }
}
