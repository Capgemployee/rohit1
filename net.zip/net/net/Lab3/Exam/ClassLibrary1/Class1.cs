﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
        private int EmpId;
        private string Name, CompanyName;
        private int FoundationMarks, WebBasicMarks, DotNetMarks,ObtainedMarks;
        private int TotalMarks = 300;
        private double Percentage;
        public Int32 empId {
            get
            {
                return EmpId;
            }
            set
            {
                if (Int32.Equals(empId, 0))
                {
                    Console.WriteLine("Enter Correct employee Id");
                }
                else
                {
                    EmpId = value;
                }
            }
        }
        public string name { get; set; }
        public string companyName { get; set; }
        public int foundationMarks{ get; set; }
        public int webBasicMarks { get; set; }
        public int dotNetMarks { get; set; }
        public int totalMarks { get; set; }
        public int obtainedMarks { get; set; }
        public double percentage { get; set; }
        public int getTotalMarks()
        {
            obtainedMarks = foundationMarks + webBasicMarks + dotNetMarks;
            return(obtainedMarks);
        }
        public double getPercentage()
        {
            return ((obtainedMarks *100)/ TotalMarks);
        }
    }
}
