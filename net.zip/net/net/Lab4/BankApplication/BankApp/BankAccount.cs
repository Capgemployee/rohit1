﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApp
{
    public abstract class BankAccount:IBankAccount
    {
        public enum BankAccountTypeEnum
        {
            Current = 1,
            Saving = 2
        }
        BankAccountTypeEnum AccountType { get; set; }
        protected double balance;
        double Deposit(double amount)
        {
            return(balance+amount);
        }
        bool Withdraw(double amount)
        {
            return true;
        }
        bool Transfer(IBankAccount toAccount, double amount)
        {
            return true;
        }
        public BankAccount()
        {
            // TODO: Complete member initialization
        }


        public double GetBalance()
        {
            throw new NotImplementedException();
        }

        void IBankAccount.Deposit(double amount)
        {
            throw new NotImplementedException();
        }

        bool IBankAccount.Withdraw(double amount)
        {
            throw new NotImplementedException();
        }

        bool IBankAccount.Transfer(IBankAccount toAccount, double amount)
        {
            throw new NotImplementedException();
        }
    }
}
