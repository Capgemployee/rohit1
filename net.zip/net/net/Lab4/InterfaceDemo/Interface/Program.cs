﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            ContractEmployee cm = new ContractEmployee();
            PermanentEmployee pm = new PermanentEmployee();
            Console.WriteLine("-------------------Employee---------------------");
            Console.WriteLine("------------------------------------------------");
            while (true)
            {
                int choice;
                Console.WriteLine("Choice--------------------------------------");
                Console.WriteLine("1)Contract Employee");
                Console.WriteLine("2)Permanent Employee");
                Console.WriteLine("Enter Choice");
                choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    Console.WriteLine("-------------Contract Employee-----------");
                    Console.WriteLine("Enter Employee ID");
                    cm.EmployeeId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Employee Name");
                    cm.EmployeeName = Console.ReadLine();
                    Console.WriteLine("Enter Employee Address");
                    cm.EmployeeAddress = Console.ReadLine();
                    Console.WriteLine("Enter Employee City");
                    cm.EmployeeCity = Console.ReadLine();
                    Console.WriteLine("Enter Employee Department");
                    cm.EmploeeDepartment = Console.ReadLine();
                    Console.WriteLine("Enter Employee Salary");
                    cm.EmployeeSalary = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Employee Perks");
                    cm.Perks = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Employee Id              :" + cm.EmployeeId);
                    Console.WriteLine("Employee Name            :"+cm.EmployeeName);
                    Console.WriteLine("Employee Address         :"+cm.EmployeeAddress);
                    Console.WriteLine("Employee City            :"+cm.EmployeeCity);
                    Console.WriteLine("Employee Department      :"+cm.EmploeeDepartment);
                    Console.WriteLine("Employee Salary          :" + cm.getSalary());
                }
                else
                {
                    Console.WriteLine("-------------Permanent-----------");
                    Console.WriteLine("Enter Employee ID");
                    pm.EmployeeId = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Employee Name");
                    pm.EmployeeName = Console.ReadLine();
                    Console.WriteLine("Enter Employee Address");
                    pm.EmployeeAddress = Console.ReadLine();
                    Console.WriteLine("Enter Employee City");
                    pm.EmployeeCity = Console.ReadLine();
                    Console.WriteLine("Enter Employee Department");
                    pm.EmploeeDepartment = Console.ReadLine();
                    Console.WriteLine("Enter Employee Salary");
                    pm.EmployeeSalary = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Employee PF");
                    pm.ProvidendFund = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Employee Id              :" + pm.EmployeeId);
                    Console.WriteLine("Employee Name            :" + pm.EmployeeName);
                    Console.WriteLine("Employee Address         :" + pm.EmployeeAddress);
                    Console.WriteLine("Employee City            :" + pm.EmployeeCity);
                    Console.WriteLine("Employee Department      :" + pm.EmploeeDepartment);
                    Console.WriteLine("Employee Salary          :" + pm.getSalary());
                }

            }


            
        }
    }
}
