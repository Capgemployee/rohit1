﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class PermanentEmployee:Employee
    {
        public int NoOfLeaves { get; set; }
        public int ProvidendFund { get; set; }
        public double getSalary()
        {
            return(EmployeeSalary-ProvidendFund);
        }
    }
}
