﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Interface
{
    class ContractEmployee:Employee
    {
        public int Perks { get; set; }
        public double getSalary()
        {
            return(EmployeeSalary+Perks);
        }
    }
}
