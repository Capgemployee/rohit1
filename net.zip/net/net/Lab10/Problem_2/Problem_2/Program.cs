﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Problem_2_ArithmaticCalculation;

delegate void MyDelegate(double num1, double num2);
namespace Problem_2_ArithmaticCalculation
{
    public class Calculate
    {
        public void Add(double num1, double num2)
        {
            Console.WriteLine("Addition " + (num1 + num2));
        }
        public void Sub(double num1, double num2)
        {
            Console.WriteLine("Addition " + (num1 - num2));
        }
        public void Mul(double num1, double num2)
        {
            Console.WriteLine("Addition " + (num1 * num2));
        }
        public void Div(double num1, double num2)
        {
            Console.WriteLine("Addition " + (num1 / num2));
        }
    }
    class Program
    {
        public void CallDelegate(double num1, double num2, MyDelegate d)
        {
            d(num1, num2);
        }
        static void Main(string[] args)
        {

            Calculate c = new Calculate();
            Program p=new Program();
            double num1, num2;
            int choice;
            Console.WriteLine(" Enter The First Number");
            num1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine(" Enter The Second Number");
            num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine(" Please Select Operation ");
            Console.WriteLine(" 1. Addition   2. Subtraction  3. Multiplication  4. Division  5. Modulus ");
            choice = Convert.ToInt32(Console.ReadLine());
            switch (choice)
            {
                case 1:
                    MyDelegate d1 = new MyDelegate(c.Add);
                    p.CallDelegate(num1, num2,d1);
                    break;

                case 2:
                    MyDelegate d2 = new MyDelegate(c.Sub);
                    p.CallDelegate(num1, num2, d2);
                    break;

                case 3:
                    MyDelegate d3 = new MyDelegate(c.Mul);
                    p.CallDelegate(num1, num2, d3);
                    break;

                case 4:
                    MyDelegate d4 = new MyDelegate(c.Div);
                    p.CallDelegate(num1, num2, d4);
                    break;

                default:
                    Console.WriteLine("Please Enter Valid Choice");
                    break;
            }
           
            Console.ReadKey();


        }
    }
}
