﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer c1 = new Customer();
            Customer c = new Customer(1001,"Dheeraj Gupta","Boisar","Boisar","8600381182",10000);
            try
            {
                if (c.PCreditLimit < 50000)
                {
                    throw new Customer("Credit limit is below 50000");
                }
            }
            catch(Customer ex)
            {
                //Console.WriteLine(c.Message);
            }
        }
    }
}
