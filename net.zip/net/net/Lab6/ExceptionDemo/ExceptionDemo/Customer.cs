﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    public class Customer : ApplicationException
    {
        int CustomerId;
        string CustomerName;
        string Address;
        string City;
        string Phone;
        int CreditLimit;
        public int PCustomerId {
            get { return CustomerId;}
            set { CustomerId=value;}
        }
        public string PCustomerName
        {
            get { return CustomerName; }
            set { CustomerName = value;}
        }
        public string PAddress
        {
            get { return Address; }
            set { Address = value; }
        }
        public string PCity
        {
            get { return City;}
            set { City = value; }
        }
        public string PPhone
        {
            get { return Phone; }
            set { Phone = value; }
        }
        public int PCreditLimit
        {
            get { return CreditLimit; }
            set { CreditLimit = value; }
        }
        //public Customer()
        //{
        //    CustomerId = 10001;
        //    CustomerName="Dheeraj Gupta";
        //    Address="Room no.6,Prabhu Niwas,Boisar";
        //    City="Boisar";
        //    Phone="8600381182";
        //    CreditLimit=200000;
        //}
        public Customer(int cid,string cname,string caddress,string city,string phone,int climit)
        {
            CustomerId = cid;
            CustomerName = cname;
            Address = caddress;
            City = city;
            Phone = phone;
            CreditLimit = climit;
        }
        public Customer()
            : base()
        { }
        public Customer(string message)
            : base(message)
        {
            Console.WriteLine(message);
        }

    }
}
