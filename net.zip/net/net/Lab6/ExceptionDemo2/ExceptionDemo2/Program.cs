﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Product p = new Product();
            Console.WriteLine("++++++++++++Product++++++++++++");
            Console.WriteLine("Enter Product ID");
            p.PId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Product Name");
            p.PName = Console.ReadLine();
            Console.WriteLine("Enter Price");
            p.PPrice = Convert.ToInt32(Console.ReadLine());
            try
            {
                if (p.PId <= 0)
                {
                    throw new Product("Enter Correct Product Id");
                }
                if (p.PName == "")
                {
                    throw new Product("Enter Correct Product name");
                }
                if (p.PPrice <= 0)
                {
                    throw new Product("Enter Correct Price");
                }
            }
            catch(Exception e)
            {
            }
        }
    }
}
