﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo2
{
    class Product:ApplicationException
    {
        int Id;
        string Name;
        int price;
        public int PId
        {
            get { return Id;}
            set { Id=value ;}
        }
        public string PName
        {
            get { return Name;}
            set { Name=value;}
        }
        public int PPrice
        {
            get { return price; }
            set { price = value; }
        }
        public Product()
            : base()
        { }
        public Product(string message)
            : base(message)
        {
            Console.WriteLine(Message);
        }

    }
}
